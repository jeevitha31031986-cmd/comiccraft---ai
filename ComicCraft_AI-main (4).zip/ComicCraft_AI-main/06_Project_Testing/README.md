# Phase 6 – Project Testing

| ID | Test | Expected Result |
|---|---|---|
| TC01 | Open `/` | Homepage loads |
| TC02 | Submit valid story | Comic preview appears |
| TC03 | Repeat same story | Cached result is used |
| TC04 | Gemini unavailable | Fallback output appears |
| TC05 | Export PDF | PDF is created |
| TC06 | Download PDF | Browser downloads PDF |
| TC07 | Open `/docs` | Swagger page loads |
| TC08 | Open `/health` | Health JSON is returned |
| TC09 | Missing story prompt | Validation error shown |
| TC10 | Double-click Generate | Button is disabled after first submit |

Add screenshots and mark each test PASS after your local verification.
