# Phase 7 – Project Documentation

## Technology Stack
- Python
- FastAPI
- Uvicorn
- Jinja2
- HTML/CSS
- Google Gemini API
- fpdf2
- GitHub

## Installation

```bash
pip install -r requirements.txt
python app.py
```

Open `http://127.0.0.1:8000/`.

## Security
Never upload the real `.env` file or API key.

## Limitations
The built-in fallback is not AI-generated. It exists only to keep the demonstration flow working when Gemini is unavailable.

## Future Enhancements
- Dedicated AI image generation
- User accounts
- Comic library
- Multi-page stories
- Cloud deployment
