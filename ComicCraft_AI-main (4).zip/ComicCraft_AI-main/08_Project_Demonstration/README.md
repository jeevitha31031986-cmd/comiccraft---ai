# Phase 8 – Project Demonstration

## Demo Video Sequence

1. Introduce the project name.
2. Explain the purpose.
3. Explain the benefits.
4. Open the ComicCraft homepage.
5. Enter the story prompt.
6. Enter the character.
7. Select setting, tone and art style.
8. Click Generate Comic.
9. Explain the five generated panels.
10. Click Create PDF.
11. Download and show the PDF.
12. Conclude the demonstration.

## Voice-over Opening

> Hello everyone. This is our project, ComicCraft – AI Comic Story Creator using Gemini Models. The purpose of this project is to transform a simple story idea into a personalized five-panel comic using AI.

## Final Submission
Upload the demonstration video to Google Drive and set it to “Anyone with the link can view”. Add the final Drive link to this file before GitHub submission.
